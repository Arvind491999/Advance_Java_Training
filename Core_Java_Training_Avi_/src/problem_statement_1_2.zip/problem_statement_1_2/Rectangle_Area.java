package problem_statement_1_2;

import java.util.*;

public class Rectangle_Area {
	
	int length,breadth,area; 
	   
    public Rectangle_Area()
    {
    	length = 0;
    	breadth= 0;
    }
    void input() {
        Scanner a = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = a.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = a.nextInt();
    }
    void calculate() {
        area = length * breadth;        
    }

    void display() {
        System.out.println("Area of the Rectangle = " + area);       
    }

    public static void main(String args[]) {
    	Rectangle_Area ob1 = new Rectangle_Area();
        ob1.input();
        ob1.calculate();
        ob1.display();
        System.out.println("=======================================");
        Rectangle_Area ob2 = new Rectangle_Area();
        ob2.input();
        ob2.calculate();
        ob2.display();
        System.out.println("=======================================");
        Rectangle_Area ob3 = new Rectangle_Area();
        ob3.input();
        ob3.calculate();
        ob3.display();
        System.out.println("=======================================");
        Rectangle_Area ob4 = new Rectangle_Area();
        ob4.input();
        ob4.calculate();
        ob4.display();
        System.out.println("=======================================");
        Rectangle_Area ob5 = new Rectangle_Area();
        ob5.input();
        ob5.calculate();
        ob5.display();
   }
}
