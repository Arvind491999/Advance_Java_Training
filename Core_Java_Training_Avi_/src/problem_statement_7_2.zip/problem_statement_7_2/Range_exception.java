package problem_statement_7_2;

public class Range_exception extends Exception {

}
