package problem_statement_7_2;

public class Range_exception_extends_excep {
	public String toString()
    {
         return ("Age is not between 15 and 21. please Retype the Age");
    }
}


